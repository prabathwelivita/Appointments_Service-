$(document).ready(function()
 {
	 $("#alertSuccess").hide();
	 $("#alertError").hide();
 });

//SAVE........
$(document).on("click", "#btnSave", function(event)
{
	//Clear alerts---------------------
	$("#alertSuccess").text("");
	$("#alertSuccess").hide();
	$("#alertError").text("");
	$("#alertError").hide(); 


	//Form validation-------------------
	var status = validateItemForm();
	if (status != true)
	 {
		 $("#alertError").text(status);
		 $("#alertError").show();
	 return;
	 }  

	//If valid------------------------
	var type = ($("#hidAppointmentIDSave").val() == "") ? "POST" : "PUT"; 
	
	$.ajax(
			{
			 url : "AppointmentsAPI",
			 type : type,
			 data : $("#formAppointment").serialize(),
			 dataType : "text",
			 complete : function(response, status)
			 {
				 onItemSaveComplete(response.responseText, status);
			 }
	});
});

function onItemSaveComplete(response, status)
{   
	if (status == "success")
	 {
		 var resultSet = JSON.parse(response);
		 
		 if (resultSet.status.trim() == "success")
		 {
			 $("#alertSuccess").text("Successfully saved.");
			 $("#alertSuccess").show();
			 
			 $("#divItemsGrid").html(resultSet.data);
		 }	else if (resultSet.status.trim() == "error")
		 {
			 $("#alertError").text(resultSet.data);
			 $("#alertError").show();
		 }
	 } else if (status == "error")
	 {
		 $("#alertError").text("Error while saving.");
		 $("#alertError").show();
	 } else
	 {
		 $("#alertError").text("Unknown error while saving..");
		 $("#alertError").show();
	 }
		 $("#hidAppointmentIDSave").val("");
		 $("#formAppointment")[0].reset(); 
} 

//remove

$(document).on("click", ".btnRemove", function(event)
		{
		 $.ajax(
		 {
			 url : "AppointmentsAPI",
			 type : "DELETE",
			 data : "id=" + $(this).data("appointmentid"),
			 dataType : "text",
			 complete : function(response, status)
			 {
				 onItemDeleteComplete(response.responseText, status);
			 }
		});
	});




function onItemDeleteComplete(response, status)
{
	if (status == "success")
	 {
		 var resultSet = JSON.parse(response);
		 if (resultSet.status.trim() == "success")
	 {
		 $("#alertSuccess").text("Successfully deleted.");
		 $("#alertSuccess").show();
		 $("#divItemsGrid").html(resultSet.data);
	 } else if (resultSet.status.trim() == "error")
	 {
		 $("#alertError").text(resultSet.data);
		 $("#alertError").show();
	 }
	 } else if (status == "error")
		 {
		 $("#alertError").text("Error while deleting.");
		 $("#alertError").show();
	 } else
	 {
		 $("#alertError").text("Unknown error while deleting..");
		 $("#alertError").show();
	 }
}

//UPDATE==========================================
$(document).on("click", ".btnUpdate", function(event)
{
 $("#hidAppointmentIDSave").val($(this).closest("tr").find('#hidAppointmentIDUpdate').val());
 $("#appointmentId").val($(this).closest("tr").find('td:eq(0)').text());
 $("#patientId").val($(this).closest("tr").find('td:eq(1)').text());
 $("#hospitalId").val($(this).closest("tr").find('td:eq(2)').text());
 $("#clinicId").val($(this).closest("tr").find('td:eq(3)').text());
 $("#doctorId").val($(this).closest("tr").find('td:eq(4)').text());
 $("#startTime").val($(this).closest("tr").find('td:eq(5)').text());
 $("#endTime").val($(this).closest("tr").find('td:eq(6)').text());
});


function validateItemForm()
{	
	if ($("#appointmentId").val().trim() == "")
	 {
		return "Insert appointment Id.";
	 }
	
	if ($("#patientId").val().trim() == "")
	 {
		return "Insert patient Id.";
	 }
	
	if ($("#hospitalId").val().trim() == "")
	 {
		return "Insert hospital Id.";
	 }
	
	if ($("#clinicId").val().trim() == "")
	 {
		return "Insert clinic Id.";
	 }
	
	if ($("#doctorId").val().trim() == "")
	 {
		return "Insert doctor Id.";
	 }
	
	if ($("#startTime").val().trim() == "")
	 {
		return "Insert start time.";
	 }
 	
	if ($("#endTime").val().trim() == "")
	 {
		return "Insert end time.";
	 }
	
 	return true;
}


