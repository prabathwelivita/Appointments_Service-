package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class Appointment {
	
	public Connection connect() {

		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Properties connectionProps = new Properties();
			connectionProps.put("user", "root");
			connectionProps.put("password", "");
			con = (Connection) DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1:3306/appointments?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=Asia/Colombo",
					connectionProps);
			// For testing
			System.out.print("Successfully connected");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public String readAppointments() {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for reading.";
			}
			// Prepare the html table to be displayed
			output = "<table border='1'>"
					+ "<tr>"
					+ "<th>appointmentId</th>"
					+ "<th>patientId</th>"
					+ "<th>hospitalId</th>"
					+ "<th>clinicId</th>"
					+ "<th>doctorId</th>"
					+ "<th>startTime</th>"
					+ "<th>endTime</th>"
					+ "<th>Update</th>"
					+ "<th>Remove</th>"
					+ "</tr>";

			String query = "select * from appointment";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			// iterate through the rows in the result set
			while (rs.next()) 
			{
				String id = Integer.toString(rs.getInt("id"));
				String appointmentId = rs.getString("appointmentId");
				String patientId = rs.getString("patientId");
				String hospitalId = rs.getString("hospitalId");
				String clinicId = rs.getString("clinicId");
				String doctorId = rs.getString("docId");
				String startTime = rs.getString("startTime");
				String endTime = rs.getString("endTime");
				
// Add into the html table
				
				output += "<tr>"
						+ "<td><input id='hidAppointmentIDUpdate' name='hidAppointmentIDUpdate=' type='hidden' value='" + id + "'>" + appointmentId + "</td>";
				output += "<td>" + patientId + "</td>";
				output += "<td>" + hospitalId + "</td>";
				output += "<td>" + clinicId + "</td>";
				output += "<td>" + doctorId + "</td>";
				output += "<td>" + startTime + "</td>";
				output += "<td>" + endTime + "</td>";
// buttons
				output += "<td><input name='btnUpdate' type='button' value='Update' class='btnUpdate btn btn-secondary'></td>"
						+ "<td><input name='btnRemove' type='button' value='Remove' class='btnRemove btn btn-danger' data-appointmentid='" + id + "'>" + "</td></tr>";
			}
			con.close();
			
// Complete the html table
			output += "</table>";
			
			}
				catch (Exception e) 
		{
			output = "Error while reading the items.";
			System.err.println(e.getMessage());
		}
		return output;
	}

	public String insertAppointment(String appointmentId, String patientId, String hospitalId, String clinicId, String doctorId, String startTime, String endTime) {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for inserting.";
			}
// create a prepared statement
			String query = " insert into appointment(appointmentId,patientId,hospitalId,clinicId,docId,startTime,endTime)"
					+ " values (?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement preparedStmt = con.prepareStatement(query);
			
// binding values
			preparedStmt.setString(1, appointmentId);
			preparedStmt.setString(2, patientId);
			preparedStmt.setString(3, hospitalId);
			preparedStmt.setString(4, clinicId);
			preparedStmt.setString(5, doctorId);
			preparedStmt.setString(6, startTime);
			preparedStmt.setString(7, endTime);
			
// execute the statement
			preparedStmt.executeUpdate();
			
			String newAppointments = readAppointments();
			output = "{\"status\":\"success\", \"data\": \"" + newAppointments+ "\"}";
			
		} catch (Exception e) 
		{
			output = "{\"status\":\"error\", \"data\":\"Error while inserting the appointment.\"}";
			System.err.println(e.getMessage());
		}
		return output;
	}

	public String updateAppointment(String id, String appointmentId, String patientId, String hospitalId, String clinicId, String doctorId, String startTime, String endTime) {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for updating.";
			}
// create a prepared statement
			String query = "UPDATE appointment SET appointmentId=?,patientId=?,hospitalId=?,clinicId=?,docId=?,startTime=?,endTime=? WHERE id=?";
			PreparedStatement preparedStmt = con.prepareStatement(query);
			
// binding values
			preparedStmt.setString(1, appointmentId);
			preparedStmt.setString(2, patientId);
			preparedStmt.setString(3, hospitalId);
			preparedStmt.setString(4, clinicId);
			preparedStmt.setString(5, doctorId);
			preparedStmt.setString(6, startTime);
			preparedStmt.setString(7, endTime);
			preparedStmt.setInt(8, Integer.parseInt(id));
			
// execute the statement
			preparedStmt.execute();
			con.close();
			
			String newAppointments = readAppointments();
			output = "{\"status\":\"success\", \"data\": \"" + newAppointments + "\"}";
			
		} catch (Exception e)
		{
			output = "{\"status\":\"error\", \"data\":\"Error while updating the appointment.\"}";
			System.err.println(e.getMessage());
		}
		return output;
	}

	public String deleteAppointment(String id) {
		String output = "";
		try {
			Connection con = connect();
			if (con == null) {
				return "Error while connecting to the database for deleting.";
			}

// create a prepared statement
			String query = "delete from appointment where id=?";
			PreparedStatement preparedStmt = con.prepareStatement(query);
			
// binding values
			preparedStmt.setInt(1, Integer.parseInt(id));
			
// execute the statement
			preparedStmt.execute();
			con.close();
			String newAppointments = readAppointments();
			
			output = "{\"status\":\"success\", \"data\": \"" + newAppointments + "\"}";
			}
				catch (Exception e)
		{
				output = "{\"status\":\"error\", \"data\":\"Error while deleting the appointment.\"}";
			System.err.println(e.getMessage());
		}
		return output;
	}
	
	public static void main(String[] args) {
		//
	}
}