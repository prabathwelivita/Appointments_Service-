package model;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ItemsAPI
 */
//@WebServlet("/AppointmentsAPI")
public class AppointmentsAPI extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	
       Appointment appointmentsobj = new Appointment();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AppointmentsAPI() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(request.getParameter("appointmentId"));
		
		String output = appointmentsobj.insertAppointment(request.getParameter("appointmentId"),
				 request.getParameter("patientId"),
				request.getParameter("hospitalId"),
				request.getParameter("clinicId"),
				request.getParameter("doctorId"),
				request.getParameter("startTime"),
				request.getParameter("endTime")); 
		
		
		response.getWriter().write(output); 
	}

	/**
	 * @see HttpServlet#doPut(HttpServletRequest, HttpServletResponse)
	 */
	protected void doPut(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {

		Map paras = getParasMap(request);
		
		String output = appointmentsobj.updateAppointment(paras.get("hidAppointmentIDSave").toString(), paras.get("appointmentId").toString(),
				paras.get("patientId").toString(), paras.get("hospitalId").toString(), paras.get("clinicId").toString(),
				paras.get("doctorId").toString(), paras.get("startTime").toString(), paras.get("endTime").toString());
		response.getWriter().write(output);
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doDelete(HttpServletRequest, HttpServletResponse)
	 */
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Map paras = getParasMap(request);
		 String output = appointmentsobj.deleteAppointment(paras.get("id").toString());
		  	 
		response.getWriter().write(output); 

		// TODO Auto-generated method stub
	}

	// Convert request parameters to a Map
	private static Map getParasMap(HttpServletRequest request) {
		Map<String, String> map = new HashMap<String, String>();
		try {
			Scanner scanner = new Scanner(request.getInputStream(), "UTF-8");
			String queryString = scanner.hasNext() ? scanner.useDelimiter("\\A").next() : "";
			scanner.close();
			
			String[] params = queryString.split("&");
			
			for (String param : params)
				{

				String[] p = param.split("=");
				map.put(p[0], p[1]);
				}
			} 
		catch (Exception e) {
	}
		return map;
	}

}
